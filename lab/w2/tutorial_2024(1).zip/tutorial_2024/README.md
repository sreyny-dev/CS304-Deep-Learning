# README

We recommend you to learning these document according to the following sequence

- jupyter_usage.ipynb
- numpy -> array.ipynb
- numpy -> array_operation.ipynb
- numpy -> slice&index.ipynb
- pytorch.ipynb

